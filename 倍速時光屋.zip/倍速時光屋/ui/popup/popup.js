(() => {
  // src/ui/popup/popup.js
  var MessageTypes = {
    SET_SPEED: "VSC_SET_SPEED",
    ADJUST_SPEED: "VSC_ADJUST_SPEED",
    RESET_SPEED: "VSC_RESET_SPEED",
    TOGGLE_DISPLAY: "VSC_TOGGLE_DISPLAY"
  };
  document.addEventListener("DOMContentLoaded", () => {
    loadSettingsAndInitialize();
    document.querySelector("#config").addEventListener("click", () => {
      chrome.runtime.openOptionsPage();
    });
    document.querySelector("#disable").addEventListener("click", function() {
      const isCurrentlyEnabled = !this.classList.contains("disabled");
      toggleEnabled(!isCurrentlyEnabled, settingsSavedReloadMessage);
    });
    chrome.storage.sync.get({ enabled: true }, (storage) => {
      toggleEnabledUI(storage.enabled);
    });
    function toggleEnabled(enabled, callback) {
      chrome.storage.sync.set(
        {
          enabled
        },
        () => {
          toggleEnabledUI(enabled);
          if (callback) {
            callback(enabled);
          }
        }
      );
    }
    function toggleEnabledUI(enabled) {
      const disableBtn = document.querySelector("#disable");
      disableBtn.classList.toggle("disabled", !enabled);
      disableBtn.title = enabled ? "\u505C\u7528\u64F4\u5145\u529F\u80FD" : "\u555F\u7528\u64F4\u5145\u529F\u80FD";
      disableBtn.setAttribute("aria-label", disableBtn.title);
      disableBtn.setAttribute("aria-pressed", String(enabled));
      document.getElementById("power-label").textContent = enabled ? "\u5DF2\u555F\u7528" : "\u5DF2\u505C\u7528";
    }
    function settingsSavedReloadMessage(enabled) {
      setStatusMessage(`${enabled ? "\u5DF2\u555F\u7528" : "\u5DF2\u505C\u7528"}\uFF0C\u8ACB\u91CD\u65B0\u6574\u7406\u7DB2\u9801\u3002`);
    }
    function setStatusMessage(str) {
      const status_element = document.querySelector("#status");
      status_element.classList.toggle("hide", false);
      status_element.innerText = str;
    }
    function loadSettingsAndInitialize() {
      chrome.storage.sync.get(null, (storage) => {
        let slowerStep = 0.1;
        let fasterStep = 0.1;
        let resetSpeed = 1;
        if (storage.keyBindings && Array.isArray(storage.keyBindings)) {
          const slowerBinding = storage.keyBindings.find((kb) => kb.action === "slower");
          const fasterBinding = storage.keyBindings.find((kb) => kb.action === "faster");
          const fastBinding = storage.keyBindings.find((kb) => kb.action === "fast");
          if (slowerBinding && typeof slowerBinding.value === "number") {
            slowerStep = slowerBinding.value;
          }
          if (fasterBinding && typeof fasterBinding.value === "number") {
            fasterStep = fasterBinding.value;
          }
          if (fastBinding && typeof fastBinding.value === "number") {
            resetSpeed = fastBinding.value;
          }
        }
        updateSpeedControlsUI(slowerStep, fasterStep, resetSpeed);
        initializeSpeedControls();
      });
    }
    function updateSpeedControlsUI(slowerStep, fasterStep, resetSpeed) {
      const decreaseBtn = document.querySelector("#speed-decrease");
      if (decreaseBtn) {
        decreaseBtn.dataset.delta = -slowerStep;
        decreaseBtn.querySelector("span").textContent = `-${slowerStep}`;
      }
      const increaseBtn = document.querySelector("#speed-increase");
      if (increaseBtn) {
        increaseBtn.dataset.delta = fasterStep;
        increaseBtn.querySelector("span").textContent = `+${fasterStep}`;
      }
      const resetBtn = document.querySelector("#speed-reset");
      if (resetBtn) {
        resetBtn.textContent = resetSpeed.toString();
      }
    }
    function initializeSpeedControls() {
      document.querySelector("#speed-decrease").addEventListener("click", function() {
        const delta = parseFloat(this.dataset.delta);
        adjustSpeed(delta);
      });
      document.querySelector("#speed-increase").addEventListener("click", function() {
        const delta = parseFloat(this.dataset.delta);
        adjustSpeed(delta);
      });
      document.querySelector("#speed-reset").addEventListener("click", function() {
        const preferredSpeed = parseFloat(this.textContent);
        setSpeed(preferredSpeed);
      });
      document.querySelectorAll(".preset-btn").forEach((btn) => {
        btn.addEventListener("click", function() {
          const speed = parseFloat(this.dataset.speed);
          setSpeed(speed);
        });
      });
    }
    function setSpeed(speed) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            {
              type: MessageTypes.SET_SPEED,
              payload: { speed }
            },
            { frameId: 0 }
          );
        }
      });
    }
    function adjustSpeed(delta) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            {
              type: MessageTypes.ADJUST_SPEED,
              payload: { delta }
            },
            { frameId: 0 }
          );
        }
      });
    }
  });
})();
