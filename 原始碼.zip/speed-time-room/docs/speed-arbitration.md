# Private per-player arbitration contract

Based on upstream v0.11.1 (`8f9bc13cd1d8bad549795da265735159d9e9fad1`). This document supersedes the upstream shared-speed adapter contract for this private build.

## State ownership

Every `HTMLMediaElement` has a WeakMap authority record `{ desired, epoch }`. Conflict phase, retry budget, timers, temporary holds, echo tokens and echo-reaction transactions also belong to that element. Each injected document/frame creates its own coordinator. No speed message is broadcast through storage.

`settings.lastSpeed` is a legacy settings field only. Neither lifecycle resolution nor preferred-speed resolution reads it. No production speed action calls `persistAuthority()` or writes `lastSpeed`. Global remember-speed UI is disabled; the checkbox now indicates mandatory per-player isolation. Other preferences remain customizable.

## Changed transitions

- LOAD: a new element starts with no opinion, preserving its native playbackRate, unless the user has an explicit site speed rule. Site rules seed each element once when its controller attaches, including deferred metadata cases.
- USER_SET and native USER_INTENT: update only the target authority and increment only its epoch. Clear only its previous retry timer, release fallback, pending writes and echo reaction. Other players' budgets and holds survive.
- LIFECYCLE (play, seeked, deferred metadata): resolve the target element's own desired speed. Never consult another media element or legacy lastSpeed.
- TEMPORARY_OVERRIDE_END: restore the same element's pre-hold desired speed, even when a peer changes speed during the hold.
- RELEASE: clear the removed controller's timers, classifier evidence and echoes. Retain only its weak authority identity, so reattaching the same DOM element restores its choice. A replacement DOM element starts fresh. Full coordinator cleanup releases all authority records.

The pure SpeedArbiter local transition table, four-retry bound, quiet-war rearm policy and site intent classifier remain unchanged. Its PERSIST effect is interpreted as a local authority claim, without storage persistence.

## Command targeting

Playback shortcuts and popup messages select one controlled element: explicit event owner, hovered owner, focused owner, recent interaction/last play, sole playing element, or sole controlled element. Multiple unselected paused players cause a no-op until a player is selected. Controller clicks, drag and wheel already name their owner. `V` keeps the original all-controller visibility behavior. Keyboard listeners stay inside their receiving frame. Popup speed commands target only frame 0, avoiding accidental changes in sibling iframes; use an iframe's own controller or focus it for keyboard control.

## Verification

`npm test` covers the private adapter, settings isolation, real event listener paths under jsdom, independent video/audio combinations and differential replays of three independent pure state machines. `npm run test:e2e:private` loads the built extension into Chrome with local WAV fixtures and checks two tabs, keyboard targeting and options. No Spotify login or external media service is required by the tests.

The upstream `specs/SpeedArbiter.tla` models *shared* authority and is retained as historical source. Running its TLC check would not verify the new private adapter. It has not been updated or claimed as proof of per-player isolation. The unchanged pure machine and visibility model retain their upstream provenance; private cross-media isolation is checked by regression and differential tests.
