import { vi } from 'vitest';
import { privateWorld } from '../helpers/private-media.js';
import { getMockStorage } from '../helpers/chrome-mock.js';
let w;
afterEach(() => w?.cleanup());
it.each([true, false])(
  'UI changes update only the target without speed storage writes (remember=%s)',
  async (remember) => {
    w = await privateWorld({ remember, storedSpeed: 3 });
    const a = w.add().el,
      b = w.add('audio').el;
    const save = vi.spyOn(w.config, 'save');
    w.actions.adjustSpeed(a, 1.25);
    w.actions.adjustSpeed(b, 2.5);
    expect(a.vsc.speedIndicator.textContent).toBe('1.25');
    expect(b.vsc.speedIndicator.textContent).toBe('2.50');
    w.actions.adjustSpeed(a, 0.1, { relative: true });
    expect(a.playbackRate).toBe(1.35);
    expect(b.playbackRate).toBe(2.5);
    expect(save).not.toHaveBeenCalled();
    expect(getMockStorage().lastSpeed).toBe(3);
  }
);
it('reset toggles are per player and clamping never changes a peer', async () => {
  w = await privateWorld();
  const a = w.add().el,
    b = w.add().el;
  w.actions.adjustSpeed(a, 1.35);
  w.actions.adjustSpeed(b, 2.4);
  w.actions.resetSpeed(a, 1);
  w.actions.resetSpeed(b, 1);
  w.actions.resetSpeed(a, 1);
  w.actions.resetSpeed(b, 1);
  expect([a.playbackRate, b.playbackRate]).toEqual([1.35, 2.4]);
  w.actions.adjustSpeed(a, 100);
  expect(a.playbackRate).toBe(16);
  expect(b.playbackRate).toBe(2.4);
});
