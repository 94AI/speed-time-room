/** Replay independent pure machines against the real three-media adapter. */
import { vi } from 'vitest';
import { privateWorld } from '../helpers/private-media.js';
import { getMockStorage } from '../helpers/chrome-mock.js';

it.each(Array.from({ length: 16 }, (_, i) => i + 1))(
  'three-player differential trace seed %s',
  async (seed) => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const w = await privateWorld();
    const A = window.VSC.SpeedArbiter,
      arb = w.events.arbitration;
    const media = [w.add().el, w.add('audio').el, w.add().el];
    const states = media.map(() => A.loadState({})),
      rates = [1, 1, 1];
    let n = seed;
    const random = () => {
      n = (Math.imul(n, 1664525) + 1013904223) >>> 0;
      return n;
    };
    const speeds = [1, 1.25, 1.8, 2.4];
    try {
      for (let step = 0; step < 180; step++) {
        const index = random() % 3,
          el = media[index],
          kind = random() % 8,
          speed = speeds[random() % speeds.length];
        const before = media.map((v) => ({ ...arb.stateFor(v).state }));
        let event;
        if (kind === 0) {
          event = { type: 'USER_SET', speed };
          w.actions.adjustSpeed(el, speed);
        } else if (kind === 1) {
          event = { type: 'LIFECYCLE' };
          const target = arb.lifecycleTarget(el);
          if (target !== null) {
            w.actions.writeRate(el, target);
          }
        } else if (kind === 2) {
          event = { type: 'TEMPORARY_OVERRIDE_START', speed: 2 };
          w.native(el, 2, 'TEMPORARY_OVERRIDE');
          rates[index] = 2;
        } else if (kind === 3 && states[index].temporaryOverride) {
          event = { type: 'TEMPORARY_OVERRIDE_END', speed };
          arb.completeTemporaryOverride(el, speed);
        } else if (kind === 4) {
          arb.release(el);
          states[index] = A.loadState({ siteRuleSpeed: states[index].desired });
          continue;
        } else {
          // End temporary holds before modelling an ordinary external observation.
          if (states[index].temporaryOverride) {
            arb.completeTemporaryOverride(el, el.playbackRate);
            states[index] = A.step(states[index], {
              type: 'TEMPORARY_OVERRIDE_END',
              speed: rates[index],
            }).state;
          }
          const verdict = kind === 5 ? 'USER_INTENT' : kind === 6 ? 'INIT_NOISE' : 'AUTONOMOUS';
          event = { type: 'EXT_RATE', speed, rateClass: verdict, quiet: true };
          // A same-value native choice is deliberately demoted by the adapter.
          if (
            states[index].mode === 'HOLDING' &&
            speed === states[index].desired &&
            verdict === 'USER_INTENT'
          ) {
            event.rateClass = 'AUTONOMOUS';
          }
          w.native(el, speed, verdict);
          rates[index] = speed;
        }
        const result = A.step(states[index], event);
        states[index] = result.state;
        for (const effect of result.effects) {
          if (effect.type === 'WRITE') {
            rates[index] = effect.speed;
          }
        }
        expect(
          arb.stateFor(el).state,
          `seed ${seed}, step ${step}, ${JSON.stringify(event)}`
        ).toEqual(states[index]);
        // Native hold completion above can write; compare rates on normal paths.
        if (!(kind === 3 && event.type !== 'TEMPORARY_OVERRIDE_END')) {
          expect(el.playbackRate).toBe(rates[index]);
        }
        for (let peer = 0; peer < 3; peer++) {
          if (peer !== index) {
            expect(arb.stateFor(media[peer]).state).toEqual(before[peer]);
          }
        }
        expect(getMockStorage().lastSpeed).toBe(3);
      }
    } finally {
      w.cleanup();
      vi.useRealTimers();
    }
  }
);
