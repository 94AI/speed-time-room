/** Single-media lifecycle adapter and pure-machine conformance. */
import { vi } from 'vitest';
import { privateWorld } from '../helpers/private-media.js';
let w;
beforeEach(() => vi.useFakeTimers({ shouldAdvanceTime: true }));
afterEach(() => {
  w?.cleanup();
  vi.useRealTimers();
});

it.each([null, 1.25, 2])(
  'matches the pure lifecycle table with initial site rule %s',
  async (siteSpeed) => {
    w = await privateWorld({ siteSpeed });
    const el = w.add().el,
      arb = w.events.arbitration,
      A = window.VSC.SpeedArbiter;
    let state = A.loadState({ siteRuleSpeed: siteSpeed });
    const sequence = [
      { type: 'USER_SET', speed: 1.8 },
      ...Array.from({ length: 6 }, () => ({
        type: 'EXT_RATE',
        speed: 1,
        rateClass: 'AUTONOMOUS',
        quiet: true,
      })),
      { type: 'LIFECYCLE' },
      { type: 'USER_SET', speed: 1.35 },
      { type: 'TEMPORARY_OVERRIDE_START', speed: 2 },
      { type: 'LIFECYCLE' },
      { type: 'TEMPORARY_OVERRIDE_END', speed: 1 },
      { type: 'EXT_RATE', speed: 1, rateClass: 'USER_INTENT' },
      { type: 'LIFECYCLE' },
    ];
    for (const event of sequence) {
      const result = A.step(state, event);
      state = result.state;
      if (event.type === 'USER_SET') {
        w.actions.adjustSpeed(el, event.speed);
      } else if (event.type === 'LIFECYCLE') {
        el.vsc.handlePlay({ type: 'play' });
      } else if (event.type === 'TEMPORARY_OVERRIDE_END') {
        arb.completeTemporaryOverride(el, event.speed);
      } else {
        w.native(
          el,
          event.speed,
          event.type === 'TEMPORARY_OVERRIDE_START' ? 'TEMPORARY_OVERRIDE' : event.rateClass
        );
      }
      expect(arb.stateFor(el).state).toEqual(state);
    }
  }
);

it('ordinary event echoes remain observable while own writes never become native intent', async () => {
  w = await privateWorld();
  const el = w.add().el,
    arb = w.events.arbitration;
  await vi.advanceTimersByTimeAsync(50);
  w.events.setupRateChangeListener(document);
  const observed = vi.fn();
  el.addEventListener('ratechange', observed);
  const classify = vi.spyOn(arb.classifier, 'classify');
  w.actions.adjustSpeed(el, 1.7);
  await vi.advanceTimersByTimeAsync(20);
  expect(observed).toHaveBeenCalledOnce();
  expect(classify).not.toHaveBeenCalled();
  expect(arb.lifecycleTarget(el)).toBe(1.7);
});
