/** Private contract: no operation on B can replace A's desired speed. */
import { vi } from 'vitest';
import { privateWorld } from '../helpers/private-media.js';
import { resetMockStorage, getMockStorage } from '../helpers/chrome-mock.js';

let worlds;
beforeEach(() => {
  vi.useFakeTimers({ shouldAdvanceTime: true });
  resetMockStorage();
  worlds = [];
});
afterEach(() => {
  worlds.forEach((w) => w.cleanup());
  vi.useRealTimers();
});
async function world(options) {
  const w = await privateWorld(options);
  worlds.push(w);
  return w;
}

it.each([
  ['video', 'video'],
  ['video', 'audio'],
  ['audio', 'audio'],
])('keeps %s and %s independent across repeated lifecycle resets', async (aTag, bTag) => {
  const w = await world();
  const a = w.add(aTag).el,
    b = w.add(bTag).el;
  w.actions.adjustSpeed(a, 1.35);
  w.actions.adjustSpeed(b, 2.4);
  for (let i = 0; i < 8; i++) {
    a.playbackRate = 1;
    a.vsc.handlePlay({ type: 'play' });
    b.playbackRate = 1;
    b.vsc.handleSeek({ type: 'seeked', target: b, timeStamp: performance.now() });
    expect([a.playbackRate, b.playbackRate]).toEqual([1.35, 2.4]);
  }
});

it('new media ignores stored and in-session lastSpeed, while a site rule seeds only new players', async () => {
  const w = await world({ storedSpeed: 3 });
  const a = w.add('video', 1.25).el;
  expect(a.playbackRate).toBe(1.25);
  expect(w.events.arbitration.lifecycleTarget(a)).toBeNull();
  w.actions.adjustSpeed(a, 2);
  const b = w.add('audio', 0.9).el;
  expect(b.playbackRate).toBe(0.9);
  expect(w.events.arbitration.lifecycleTarget(b)).toBeNull();
  w.config.settings.siteDefaultSpeed = 1.7;
  const c = w.add().el;
  expect(c.playbackRate).toBe(1.7);
  expect(w.events.arbitration.lifecycleTarget(a)).toBe(2);
  expect(w.events.arbitration.lifecycleTarget(b)).toBeNull();
});

it('deferred metadata and source replacement restore only that element', async () => {
  const w = await world();
  const a = w.add('video', 1, 0).el,
    b = w.add('audio').el;
  w.actions.adjustSpeed(a, 1.4);
  w.actions.adjustSpeed(b, 2.2);
  a.playbackRate = 1;
  a.dispatchEvent(new Event('loadedmetadata'));
  expect(a.playbackRate).toBe(1.4);
  a.dispatchEvent(new Event('loadstart'));
  a.vsc.handlePlay({ type: 'play' });
  expect([a.playbackRate, b.playbackRate]).toEqual([1.4, 2.2]);
});

it('native choices, including Normal, change only their owner', async () => {
  const w = await world();
  const a = w.add().el,
    b = w.add('audio').el;
  w.actions.adjustSpeed(a, 1.4);
  w.actions.adjustSpeed(b, 2);
  w.native(b, 1, 'USER_INTENT');
  expect(w.events.arbitration.lifecycleTarget(a)).toBe(1.4);
  expect(w.events.arbitration.lifecycleTarget(b)).toBe(1);
  expect(getMockStorage().lastSpeed).toBe(3);
});

it('changing B preserves A echo transaction, pending token and fight timer', async () => {
  const w = await world();
  const a = w.add().el,
    b = w.add().el,
    arb = w.events.arbitration;
  w.actions.adjustSpeed(a, 1.5);
  w.native(a, 1);
  const conflict = arb.conflicts.get(a),
    timer = conflict.fightTimer;
  arb.noteWrite(a, 1.5);
  arb.observePropagatedEcho(a, new Event('ratechange'), {
    rate: 1.5,
    epoch: arb.authorityFor(a).epoch,
  });
  const transaction = arb.echoTransactions.get(a);
  w.actions.adjustSpeed(b, 2.5);
  expect(arb.echoTransactions.get(a)).toBe(transaction);
  expect(arb.conflicts.get(a).fightTimer).toBe(timer);
  expect(arb.consumeEcho(a, 1.5)).toBeTruthy();
  await vi.advanceTimersByTimeAsync(3001);
  expect(arb.conflicts.get(a).fightCount).toBe(0);
  expect(arb.lifecycleTarget(a)).toBe(1.5);
});

it('surrender on A stays local and B cannot rearm A even with the same speed', async () => {
  const w = await world();
  const a = w.add().el,
    b = w.add().el,
    arb = w.events.arbitration;
  w.actions.adjustSpeed(a, 1.5);
  w.actions.adjustSpeed(b, 2);
  arb.classifier.observeInput({ timeStamp: performance.now() });
  for (let i = 0; i < 5; i++) {
    w.native(a, 1);
  }
  expect(arb.stateFor(a).state.mode).toBe('SUPPRESSED');
  w.actions.adjustSpeed(b, 1.5);
  expect(arb.lifecycleTarget(a)).toBeNull();
  expect(arb.lifecycleTarget(b)).toBe(1.5);
  w.actions.adjustSpeed(a, 1.5);
  expect(arb.lifecycleTarget(a)).toBe(1.5);
});

it('native hold release restores A even after B claims a new speed', async () => {
  const w = await world();
  const a = w.add().el,
    b = w.add().el,
    arb = w.events.arbitration;
  w.actions.adjustSpeed(a, 1.35);
  w.actions.adjustSpeed(b, 2.4);
  w.native(a, 2, 'TEMPORARY_OVERRIDE');
  w.actions.adjustSpeed(b, 1.8);
  expect(arb.lifecycleTarget(a)).toBeNull();
  w.native(a, 1);
  expect([a.playbackRate, b.playbackRate]).toEqual([1.35, 1.8]);
});

it('controller removal preserves the same element identity but leaves new elements fresh', async () => {
  const w = await world();
  const a = w.add().el,
    b = w.add().el,
    arb = w.events.arbitration;
  w.actions.adjustSpeed(a, 1.3);
  w.actions.adjustSpeed(b, 2.6);
  const conflictB = arb.conflicts.get(b);
  a.vsc.remove();
  expect(arb.conflicts.get(a)).toBeUndefined();
  expect(arb.pendingWrites.get(a)).toBeUndefined();
  new window.VSC.VideoController(a, a.parentElement, w.config, w.actions);
  expect(arb.lifecycleTarget(a)).toBe(1.3);
  expect(arb.conflicts.get(b)).toBe(conflictB);
  expect(arb.lifecycleTarget(w.add().el)).toBeNull();
});

it('independent document instances ignore shared storage changes', async () => {
  const first = await world(),
    second = await world();
  const a = first.add().el,
    b = second.add('audio').el;
  first.actions.adjustSpeed(a, 1.25);
  second.actions.adjustSpeed(b, 2.75);
  await window.VSC.StorageManager.set({ lastSpeed: 4 });
  await vi.advanceTimersByTimeAsync(500);
  expect(first.events.arbitration.lifecycleTarget(a)).toBe(1.25);
  expect(second.events.arbitration.lifecycleTarget(b)).toBe(2.75);
});
