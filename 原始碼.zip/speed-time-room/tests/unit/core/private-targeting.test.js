import { vi } from 'vitest';
import { privateWorld } from '../../helpers/private-media.js';
let w;
afterEach(() => w?.cleanup());
async function setup() {
  w = await privateWorld();
  const a = w.add().el,
    b = w.add('audio').el;
  return { a, b };
}
it('ambiguous paused players require a selection', async () => {
  const { a, b } = await setup();
  w.actions.runAction('faster', 0.1);
  expect([a.playbackRate, b.playbackRate]).toEqual([1, 1]);
});
it('hover selects only one player and recent interaction survives pointer exit', async () => {
  const { a, b } = await setup();
  w.events.setupTargetSelection(document);
  a.dispatchEvent(new Event('pointermove', { bubbles: true }));
  w.actions.runAction('faster', 0.1);
  expect([a.playbackRate, b.playbackRate]).toEqual([1.1, 1]);
  document.body.dispatchEvent(new Event('pointermove', { bubbles: true }));
  w.actions.runAction('faster', 0.1);
  expect([a.playbackRate, b.playbackRate]).toEqual([1.2, 1]);
});
it('controller buttons in shadow DOM select their owner', async () => {
  const { a, b } = await setup();
  w.actions.rememberTarget(a);
  w.actions.runAction('SET_SPEED', 2, { target: b.vsc.div, composedPath: () => [b.vsc.div] });
  expect([a.playbackRate, b.playbackRate]).toEqual([1, 2]);
});
it('focus and the sole playing audio can select hidden podcast media', async () => {
  const { a, b } = await setup();
  Object.defineProperty(b, 'paused', { value: false, configurable: true });
  w.actions.runAction('faster', 0.1);
  expect([a.playbackRate, b.playbackRate]).toEqual([1, 1.1]);
});
it('V preserves broadcast visibility while playback selection remains local', async () => {
  const { a, b } = await setup();
  const toggle = vi.spyOn(w.actions, 'toggleControllerVisibility');
  w.actions.runAction('display');
  expect(toggle).toHaveBeenCalledTimes(2);
  w.actions.rememberTarget(b);
  w.actions.runAction('faster', 0.1);
  expect([a.playbackRate, b.playbackRate]).toEqual([1, 1.1]);
});
it('only the receiving document owns keyboard listeners', async () => {
  await setup();
  const add = vi.spyOn(document, 'addEventListener');
  w.events.setupKeyboardShortcuts(document);
  expect(add.mock.calls.filter(([type]) => type === 'keydown')).toHaveLength(1);
});
it('removed selections cannot silently target an unrelated paused player among several', async () => {
  const { a, b } = await setup();
  w.actions.rememberTarget(a);
  a.vsc.remove();
  const c = w.add().el;
  w.actions.runAction('faster', 0.1);
  expect([b.playbackRate, c.playbackRate]).toEqual([1, 1]);
});
