import { privateWorld } from '../../helpers/private-media.js';
let w;
afterEach(() => w?.cleanup());
it.each([false, true])('legacy rememberSpeed=%s cannot seed a player', async (remember) => {
  w = await privateWorld({ remember, storedSpeed: 3 });
  const a = w.add('video', 1.2).el;
  expect(a.playbackRate).toBe(1.2);
  expect(w.events.arbitration.lifecycleTarget(a)).toBeNull();
});
it('an explicit site default is overridable per player', async () => {
  w = await privateWorld({ siteSpeed: 2 });
  const a = w.add().el,
    b = w.add().el;
  expect([a.playbackRate, b.playbackRate]).toEqual([2, 2]);
  w.actions.adjustSpeed(a, 1.4);
  w.actions.adjustSpeed(b, 1);
  expect(w.events.arbitration.lifecycleTarget(a)).toBe(1.4);
  expect(w.events.arbitration.lifecycleTarget(b)).toBe(1);
});
it('deferred player snapshots its own site seed before another player changes', async () => {
  w = await privateWorld({ siteSpeed: 1.7 });
  const a = w.add('audio', 1, 0).el;
  // Claim at attachment, even though metadata has not loaded yet.
  w.events.arbitration.stateFor(a);
  const b = w.add().el;
  w.actions.adjustSpeed(b, 2.5);
  a.dispatchEvent(new Event('loadedmetadata'));
  expect(a.playbackRate).toBe(1.7);
  expect(b.playbackRate).toBe(2.5);
});
