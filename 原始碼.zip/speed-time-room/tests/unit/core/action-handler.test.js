/**
 * Unit tests for ActionHandler class
 * Using global variables to match browser extension architecture
 */

import {
  installChromeMock,
  cleanupChromeMock,
  resetMockStorage,
} from '../../helpers/chrome-mock.js';
import { createMockVideo, createMockDOM } from '../../helpers/test-utils.js';

// Load all required modules

let mockDOM;

describe('ActionHandler', () => {
  beforeEach(() => {
    installChromeMock();
    resetMockStorage();
    mockDOM = createMockDOM();

    // Clear state manager for tests
    if (window.VSC && window.VSC.stateManager) {
      window.VSC.stateManager.controllers.clear();
    }

    // Initialize site handler manager for tests
    if (window.VSC && window.VSC.siteHandlerManager) {
      window.VSC.siteHandlerManager.initialize(document);
    }
  });

  /**
   * Helper function to create a test video with a controller
   * This replaces the old pattern of config.addMediaElement()
   */
  function createTestVideoWithController(config, actionHandler, videoOptions = {}) {
    const mockVideo = createMockVideo(videoOptions);

    // Ensure the video has a proper parent element for DOM operations
    if (!mockVideo.parentElement) {
      const parentDiv = document.createElement('div');
      document.body.appendChild(parentDiv);
      parentDiv.appendChild(mockVideo);
    }

    // Store initial playback rate to preserve test expectations
    const initialPlaybackRate = mockVideo.playbackRate;

    // Create a proper VideoController for this video
    new window.VSC.VideoController(mockVideo, mockVideo.parentElement, config, actionHandler);

    // Restore initial playback rate for test consistency
    mockVideo.playbackRate = initialPlaybackRate;

    return mockVideo;
  }

  afterEach(() => {
    cleanupChromeMock();
    if (mockDOM) {
      mockDOM.cleanup();
    }
  });

  it('ActionHandler should set video speed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true; // Enable persistence for this test

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler);

    actionHandler.adjustSpeed(mockVideo, 2.0);

    expect(mockVideo.playbackRate).toBe(2.0);
    expect(mockVideo.vsc.speedIndicator.textContent).toBe('2.00');
    expect(eventManager.arbitration.stateFor(mockVideo).state.desired).toBe(2.0);
  });

  it('ActionHandler should handle faster action', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });

    actionHandler.runAction('faster', 0.1);

    expect(mockVideo.playbackRate).toBe(1.1);
  });

  it('ActionHandler should handle slower action', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });

    actionHandler.runAction('slower', 0.1);
    expect(mockVideo.playbackRate).toBe(0.9);
  });

  it('ActionHandler should respect speed limits', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { playbackRate: 16.0 });

    // Should not exceed maximum speed
    actionHandler.runAction('faster', 1.0);
    expect(mockVideo.playbackRate).toBe(16.0);

    // Test minimum speed
    mockVideo.playbackRate = 0.07;
    actionHandler.runAction('slower', 0.1);
    expect(mockVideo.playbackRate).toBe(0.07);
  });

  it('ActionHandler should handle pause action', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { paused: false });

    actionHandler.runAction('pause');
    expect(mockVideo.paused).toBe(true);
  });

  it('ActionHandler should handle mute action', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { muted: false });
    actionHandler.runAction('muted');

    expect(mockVideo.muted).toBe(true);
  });

  it('ActionHandler should handle volume actions', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { volume: 0.5 });
    actionHandler.runAction('louder', 0.1);
    expect(mockVideo.volume).toBe(0.6);

    actionHandler.runAction('softer', 0.2);
    expect(mockVideo.volume).toBe(0.4);
  });

  it('ActionHandler should handle seek actions', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { currentTime: 50 });

    actionHandler.runAction('advance', 10);
    expect(mockVideo.currentTime).toBe(60);

    actionHandler.runAction('rewind', 5);
    expect(mockVideo.currentTime).toBe(55);
  });

  it('ActionHandler should handle mark and jump actions', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { currentTime: 30 });

    // Set mark
    actionHandler.runAction('mark');
    expect(mockVideo.vsc.mark).toBe(30);

    // Change time
    mockVideo.currentTime = 50;

    // Jump to mark
    actionHandler.runAction('jump');
    expect(mockVideo.currentTime).toBe(30);
  });

  it('ActionHandler should work with mark/jump key bindings', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const actionHandler = new window.VSC.ActionHandler(config, null);
    const eventManager = new window.VSC.EventManager(config, actionHandler);
    actionHandler.eventManager = eventManager;

    const mockVideo = createTestVideoWithController(config, actionHandler, { currentTime: 25 });
    // Set initial mark to undefined for test
    mockVideo.vsc.mark = undefined;

    // Verify mark key binding exists (M = 77)
    const markBinding = config.settings.keyBindings.find((kb) => kb.action === 'mark');
    expect(markBinding).toBeDefined();
    expect(markBinding.key).toBe(77);

    // Verify jump key binding exists (J = 74)
    const jumpBinding = config.settings.keyBindings.find((kb) => kb.action === 'jump');
    expect(jumpBinding).toBeDefined();
    expect(jumpBinding.key).toBe(74);

    // Simulate pressing M key to set mark
    eventManager.handleKeydown({
      code: 'KeyM',
      key: 'm',
      keyCode: 77,
      target: document.body,
      ctrlKey: false,
      altKey: false,
      shiftKey: false,
      metaKey: false,
      isComposing: false,
      timeStamp: 1000,
      preventDefault: () => {},
      stopPropagation: () => {},
    });
    expect(mockVideo.vsc.mark).toBe(25);

    // Change video time
    mockVideo.currentTime = 60;

    // Simulate pressing J key to jump to mark
    eventManager.handleKeydown({
      code: 'KeyJ',
      key: 'j',
      keyCode: 74,
      target: document.body,
      ctrlKey: false,
      altKey: false,
      shiftKey: false,
      metaKey: false,
      isComposing: false,
      timeStamp: 2000,
      preventDefault: () => {},
      stopPropagation: () => {},
    });
    expect(mockVideo.currentTime).toBe(25);
  });

  it('display samples AUTO once, then alternates persistent HIDE and SHOW', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler);
    const controller = video.vsc.div;
    const isControllerVisible = vi
      .spyOn(actionHandler, 'isControllerVisible')
      .mockReturnValueOnce(true);

    actionHandler.runAction('display', null, null);
    expect(controller.dataset.vscVisibility).toBe('hide');
    expect(controller.classList.contains('vsc-hidden')).toBe(false);

    actionHandler.runAction('display', null, null);
    expect(controller.dataset.vscVisibility).toBe('show');

    actionHandler.runAction('display', null, null);
    expect(controller.dataset.vscVisibility).toBe('hide');

    actionHandler.runAction('display', null, null);
    expect(controller.dataset.vscVisibility).toBe('show');
    expect(controller.classList.contains('vsc-hidden')).toBe(false);
    expect(isControllerVisible).toHaveBeenCalledTimes(1);
  });

  it('display preserves startHidden beneath persistent show/hide intent', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.startHidden = true;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler);
    const controller = video.vsc.div;
    vi.spyOn(actionHandler, 'isControllerVisible').mockReturnValue(false);

    expect(controller.classList.contains('vsc-hidden')).toBe(true);

    actionHandler.runAction('display', null, null);
    expect(controller.dataset.vscVisibility).toBe('show');
    expect(controller.classList.contains('vsc-hidden')).toBe(true);

    actionHandler.runAction('display', null, null);
    expect(controller.dataset.vscVisibility).toBe('hide');
    expect(controller.classList.contains('vsc-hidden')).toBe(true);
  });

  it('display samples an active flash before clearing it', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.startHidden = false;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler);
    const controller = video.vsc.div;
    vi.spyOn(actionHandler, 'isControllerVisible').mockImplementation(() => {
      expect(controller.classList.contains('vsc-show')).toBe(true);
      return true;
    });

    vi.useFakeTimers();
    try {
      actionHandler.flashController(controller, 1000);
      expect(controller.flashTimer).toBeDefined();
      expect(controller.classList.contains('vsc-show')).toBe(true);

      actionHandler.runAction('display', null, null);
      expect(controller.flashTimer).toBeUndefined();
      expect(controller.classList.contains('vsc-show')).toBe(false);
      expect(controller.dataset.vscVisibility).toBe('hide');

      await vi.advanceTimersByTimeAsync(1000);
      expect(controller.dataset.vscVisibility).toBe('hide');
    } finally {
      vi.useRealTimers();
    }
  });

  it('isControllerVisible reads the rendered shadow controller', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    config.settings.startHidden = false;
    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler);
    const controller = video.vsc.div;
    const innerController = controller.shadowRoot.querySelector('#controller');
    let hostStyle = { display: 'block', visibility: 'visible' };
    let innerStyle = { display: 'block', visibility: 'visible' };
    const getComputedStyle = vi.spyOn(window, 'getComputedStyle').mockImplementation((element) => {
      return element === controller ? hostStyle : innerStyle;
    });

    hostStyle = { display: 'none', visibility: 'visible' };
    expect(actionHandler.isControllerVisible(controller)).toBe(false);

    hostStyle = { display: 'block', visibility: 'visible' };
    innerStyle = { display: 'none', visibility: 'visible' };
    expect(actionHandler.isControllerVisible(controller)).toBe(false);

    innerStyle = { display: 'block', visibility: 'hidden' };
    expect(actionHandler.isControllerVisible(controller)).toBe(false);

    innerStyle = { display: 'block', visibility: 'visible' };
    expect(actionHandler.isControllerVisible(controller)).toBe(true);
    expect(getComputedStyle).toHaveBeenCalledWith(controller);
    expect(getComputedStyle).toHaveBeenCalledWith(innerController);
  });

  // --- flashController visibility rules ---

  it('flashController: startHidden=true → never flashes, even after V toggle', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.startHidden = true;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler);
    const controller = video.vsc.div;

    // Before any V toggle
    actionHandler.flashController(controller);
    expect(controller.classList.contains('vsc-show')).toBe(false);

    // After user presses V (explicitly shows the controller)
    controller.dataset.vscVisibility = 'show';
    actionHandler.flashController(controller);
    expect(controller.classList.contains('vsc-show')).toBe(false);
  });

  it('flashController: startHidden=false → flashes on speed change', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.startHidden = false;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler);
    const controller = video.vsc.div;

    actionHandler.flashController(controller);
    expect(controller.classList.contains('vsc-show')).toBe(true);
  });

  it('flashController: explicit hide override does not flash', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.startHidden = false;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler);
    const controller = video.vsc.div;

    controller.dataset.vscVisibility = 'hide';

    actionHandler.flashController(controller);
    expect(controller.classList.contains('vsc-show')).toBe(false);
  });

  it('ActionHandler should work with videos in nested shadow DOM', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    // Create nested shadow DOM structure
    const host = document.createElement('div');
    const level1Shadow = host.attachShadow({ mode: 'open' });

    const nestedHost = document.createElement('div');
    level1Shadow.appendChild(nestedHost);
    const level2Shadow = nestedHost.attachShadow({ mode: 'open' });

    const mockVideo = createMockVideo({ playbackRate: 1.0 });
    level2Shadow.appendChild(mockVideo);

    document.body.appendChild(host);

    // Create a proper mock speedIndicator that behaves like a real DOM element
    const mockSpeedIndicator = {
      textContent: '1.00',
      // Add other properties that might be needed
      nodeType: 1,
      tagName: 'SPAN',
    };

    // Mock video controller structure for shadow DOM video
    mockVideo.vsc = {
      div: mockDOM.container,
      speedIndicator: mockSpeedIndicator,
      // Add remove method to prevent errors during cleanup
      remove: () => {},
    };

    // Register with state manager for runAction to find it
    window.VSC.stateManager.controllers.set('shadow-dom-test', {
      id: 'shadow-dom-test',
      element: mockVideo,
      videoSrc: mockVideo.currentSrc || 'test-video',
      tagName: 'VIDEO',
      created: Date.now(),
      isActive: true,
    });

    // Test speed change on shadow DOM video
    actionHandler.runAction('faster', 0.2);
    expect(mockVideo.playbackRate).toBe(1.2);

    // Test slower action
    actionHandler.runAction('slower', 0.1);
    expect(mockVideo.playbackRate).toBe(1.1);

    // Test direct speed setting
    actionHandler.adjustSpeed(mockVideo, 2.5);
    expect(mockVideo.playbackRate).toBe(2.5);
    expect(mockVideo.vsc.speedIndicator.textContent).toBe('2.50');
  });

  it('adjustSpeed should handle absolute speed changes', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true; // Enable persistence for this test

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createMockVideo({ playbackRate: 1.0 });
    mockVideo.vsc = {
      div: mockDOM.container,
      speedIndicator: { textContent: '1.00' },
    };

    // Test absolute speed change
    actionHandler.adjustSpeed(mockVideo, 1.5);
    expect(mockVideo.playbackRate).toBe(1.5);
    expect(mockVideo.vsc.speedIndicator.textContent).toBe('1.50');
    expect(eventManager.arbitration.stateFor(mockVideo).state.desired).toBe(1.5);

    // Test speed limits
    actionHandler.adjustSpeed(mockVideo, 20); // Above max
    expect(mockVideo.playbackRate).toBe(16); // Clamped to max

    actionHandler.adjustSpeed(mockVideo, 0.01); // Below min
    expect(mockVideo.playbackRate).toBe(0.07); // Clamped to min
  });

  it('adjustSpeed should handle relative speed changes', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createMockVideo({ playbackRate: 1.0 });
    mockVideo.vsc = {
      div: mockDOM.container,
      speedIndicator: { textContent: '1.00' },
    };

    // Test relative speed increase
    actionHandler.adjustSpeed(mockVideo, 0.5, { relative: true });
    expect(mockVideo.playbackRate).toBe(1.5);

    // Test relative speed decrease
    actionHandler.adjustSpeed(mockVideo, -0.3, { relative: true });
    expect(mockVideo.playbackRate).toBe(1.2);

    // Test relative with limits
    mockVideo.playbackRate = 15.9;
    actionHandler.adjustSpeed(mockVideo, 0.5, { relative: true });
    expect(mockVideo.playbackRate).toBe(16); // Clamped to max
  });

  it('writeRate and syncIndicator never touch authority (lastSpeed)', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const mockVideo = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });

    // User action: full USER_SET effect row — register AND authority move.
    actionHandler.adjustSpeed(mockVideo, 1.5);
    expect(eventManager.arbitration.stateFor(mockVideo).state.desired).toBe(1.5);

    // Lifecycle/observe execution uses the bare primitives — the register
    // and UI move, authority must not (persistence purity I2).
    actionHandler.writeRate(mockVideo, 2.0);
    actionHandler.syncIndicator(mockVideo, 2.0);
    expect(mockVideo.playbackRate).toBe(2.0);
    expect(eventManager.arbitration.stateFor(mockVideo).state.desired).toBe(1.5);

    // The next user action updates both again.
    actionHandler.adjustSpeed(mockVideo, 2.5);
    expect(mockVideo.playbackRate).toBe(2.5);
    expect(eventManager.arbitration.stateFor(mockVideo).state.desired).toBe(2.5);
  });

  it('preferred speed reads each player rather than global lastSpeed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.lastSpeed = 3;
    const em = new window.VSC.EventManager(config, null);
    const action = new window.VSC.ActionHandler(config, em);
    const a = createTestVideoWithController(config, action);
    const b = createTestVideoWithController(config, action);
    action.adjustSpeed(a, 1.25);
    action.adjustSpeed(b, 2.5);
    expect(action.getPreferredSpeed(a)).toBe(1.25);
    expect(action.getPreferredSpeed(b)).toBe(2.5);
    expect(config.settings.lastSpeed).toBe(3);
  });

  it('adjustSpeed should validate input properly', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    // Test with null video
    actionHandler.adjustSpeed(null, 1.5);
    // Should not throw, just log warning

    // Test with video without controller
    const mockVideo = createMockVideo({ playbackRate: 1.0 });
    delete mockVideo.vsc;
    const initialSpeed = mockVideo.playbackRate;
    actionHandler.adjustSpeed(mockVideo, 1.5);
    expect(mockVideo.playbackRate).toBe(initialSpeed); // Should not change

    // Test with invalid value types
    const validVideo = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });

    // String value
    actionHandler.adjustSpeed(validVideo, '1.5');
    expect(validVideo.playbackRate).toBe(1.0); // Should not change

    // null value
    actionHandler.adjustSpeed(validVideo, null);
    expect(validVideo.playbackRate).toBe(1.0); // Should not change

    // undefined value
    actionHandler.adjustSpeed(validVideo, undefined);
    expect(validVideo.playbackRate).toBe(1.0); // Should not change

    // NaN value
    actionHandler.adjustSpeed(validVideo, NaN);
    expect(validVideo.playbackRate).toBe(1.0); // Should not change
  });

  it('user speed changes never write shared speed storage', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true;
    const save = vi.spyOn(config, 'save');
    const em = new window.VSC.EventManager(config, null);
    const action = new window.VSC.ActionHandler(config, em);
    const video = createTestVideoWithController(config, action);
    action.adjustSpeed(video, 1.5);
    expect(save).not.toHaveBeenCalled();
    expect(em.arbitration.lifecycleTarget(video)).toBe(1.5);
    save.mockRestore();
  });

  it('do not persist video speed to storage', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = false;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    // Create two different videos with controllers
    const video1 = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://example.com/video1.mp4',
    });
    const video2 = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://example.com/video2.mp4',
    });

    // Track saves to verify behavior
    const savedCalls = [];
    const originalSave = config.save;
    config.save = (data) => {
      savedCalls.push({ ...data });
      return originalSave.call(config, data);
    };

    // Change speeds on different videos
    await actionHandler.adjustSpeed(video1, 1.5);
    await actionHandler.adjustSpeed(video2, 2.0);

    // With rememberSpeed = false, no speeds should be persisted to storage
    expect(savedCalls.length).toBe(0);

    // Videos should still have their playback rates set
    expect(video1.playbackRate).toBe(1.5);
    expect(video2.playbackRate).toBe(2.0);
  });

  it('rememberSpeed: true does not store shared speed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true;

    // Clear any existing speeds from previous tests

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video1 = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://example.com/video1.mp4',
    });
    const video2 = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://example.com/video2.mp4',
    });

    // Change speeds on different videos
    await actionHandler.adjustSpeed(video1, 1.5);
    await actionHandler.adjustSpeed(video2, 2.0);

    // Global lastSpeed should be updated
    expect(eventManager.arbitration.stateFor(video2).state.desired).toBe(2.0);
  });

  it('speed limits should be enforced correctly', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const actionHandler = new window.VSC.ActionHandler(config, null);
    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });

    // Test minimum speed limit
    await actionHandler.adjustSpeed(video, 0.01); // Below minimum
    expect(video.playbackRate).toBe(0.07); // Should clamp to minimum

    // Test maximum speed limit
    await actionHandler.adjustSpeed(video, 20.0); // Above maximum
    expect(video.playbackRate).toBe(16.0); // Should clamp to maximum

    // Test negative speed (should clamp to minimum)
    await actionHandler.adjustSpeed(video, -1.0);
    expect(video.playbackRate).toBe(0.07);
  });

  // COMPREHENSIVE PHASE 6 TESTS
  it('adjustSpeed should handle complex relative mode scenarios', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const actionHandler = new window.VSC.ActionHandler(config, null);
    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 2.0 });

    // Test relative from various starting points
    actionHandler.adjustSpeed(video, 0.25, { relative: true });
    expect(video.playbackRate).toBe(2.25);

    // Test relative with float precision
    actionHandler.adjustSpeed(video, 0.33, { relative: true });
    expect(video.playbackRate).toBe(2.58); // Should be rounded to 2 decimals

    // Test relative from very low speed
    video.playbackRate = 0.05; // Below 0.1 threshold
    actionHandler.adjustSpeed(video, 0.1, { relative: true });
    expect(video.playbackRate).toBe(0.1); // Should use 0.0 as base for very low speeds

    // Test large relative changes
    video.playbackRate = 1.0;
    actionHandler.adjustSpeed(video, 5.0, { relative: true });
    expect(video.playbackRate).toBe(6.0);
  });

  it('adjustSpeed is always a user action: authority follows the register', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true;
    config.settings.lastSpeed = 1.25;

    const actionHandler = new window.VSC.ActionHandler(config, null);
    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });

    // Every adjustSpeed call is USER_SET (cells 5/12): the register and
    // the session authority move together, unconditionally.
    actionHandler.adjustSpeed(video, 1.5);
    expect(video.playbackRate).toBe(1.5);
    expect(video.vsc.arbitration.stateFor(video).state.desired).toBe(1.5);

    actionHandler.adjustSpeed(video, 1.8);
    expect(video.playbackRate).toBe(1.8);
    expect(video.vsc.arbitration.stateFor(video).state.desired).toBe(1.8);
  });

  it('adjustSpeed should work correctly with multiple videos', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true; // Enable persistence for this test

    const actionHandler = new window.VSC.ActionHandler(config, null);

    // Create multiple videos with different sources
    const video1 = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://site1.com/video1.mp4',
    });
    const video2 = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://site2.com/video2.mp4',
    });
    const video3 = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://site1.com/video3.mp4',
    });

    // Set different speeds for each video
    actionHandler.adjustSpeed(video1, 1.5);
    actionHandler.adjustSpeed(video2, 2.0);
    actionHandler.adjustSpeed(video3, 1.25);

    // Verify each video has correct speed
    expect(video1.playbackRate).toBe(1.5);
    expect(video2.playbackRate).toBe(2.0);
    expect(video3.playbackRate).toBe(1.25);

    // Verify global speed behavior - all videos share same preferred speed
    expect(actionHandler.getPreferredSpeed(video1)).toBe(1.5);
    expect(actionHandler.getPreferredSpeed(video2)).toBe(2.0);
    expect(actionHandler.getPreferredSpeed(video3)).toBe(1.25);
  });

  it('preferred speed reads each player rather than global lastSpeed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.lastSpeed = 3;
    const em = new window.VSC.EventManager(config, null);
    const action = new window.VSC.ActionHandler(config, em);
    const a = createTestVideoWithController(config, action);
    const b = createTestVideoWithController(config, action);
    action.adjustSpeed(a, 1.25);
    action.adjustSpeed(b, 2.5);
    expect(action.getPreferredSpeed(a)).toBe(1.25);
    expect(action.getPreferredSpeed(b)).toBe(2.5);
    expect(config.settings.lastSpeed).toBe(3);
  });

  it('adjustSpeed should handle edge cases and error conditions', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const actionHandler = new window.VSC.ActionHandler(config, null);

    // Test with video missing vsc property
    const videoNoVsc = createMockVideo({ playbackRate: 1.0 });
    actionHandler.adjustSpeed(videoNoVsc, 1.5); // Should not crash, just warn

    // Test with video missing speedIndicator
    const videoNoIndicator = createMockVideo({ playbackRate: 1.0 });
    videoNoIndicator.vsc = {}; // No speedIndicator
    // Manually register with state manager for this edge case test
    window.VSC.stateManager.controllers.set('test-no-indicator', {
      id: 'test-no-indicator',
      element: videoNoIndicator,
      videoSrc: 'test-video',
      tagName: 'VIDEO',
      created: Date.now(),
      isActive: true,
    });
    actionHandler.adjustSpeed(videoNoIndicator, 1.5); // Should work but skip UI update
    expect(videoNoIndicator.playbackRate).toBe(1.5);

    // Test with very small incremental changes
    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });

    actionHandler.adjustSpeed(video, 0.001, { relative: true });
    expect(video.playbackRate).toBe(1.0); // Should round to 2 decimals (1.00)

    actionHandler.adjustSpeed(video, 0.01, { relative: true });
    expect(video.playbackRate).toBe(1.01); // Should round to 1.01
  });

  it('external observation (SYNC_UI) preserves lastSpeed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = true;
    config.settings.lastSpeed = 1.5;

    const actionHandler = new window.VSC.ActionHandler(config, null);
    const video = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://example.com/video.mp4',
    });

    actionHandler.adjustSpeed(video, 1.5);
    // A site set the rate; the arbiter's observe branch (cells 3/10) only
    // syncs the UI — authority is untouched.
    video.playbackRate = 3.0;
    actionHandler.syncIndicator(video, 3.0);
    expect(video.vsc.speedIndicator.textContent).toBe('3.00');
    expect(video.vsc.arbitration.stateFor(video).state.desired).toBe(1.5);

    // A user action updates both.
    actionHandler.adjustSpeed(video, 1.8);
    expect(video.playbackRate).toBe(1.8);
    expect(video.vsc.arbitration.stateFor(video).state.desired).toBe(1.8);
  });

  it('reset action should use configured reset speed value', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    // Test with default reset speed (1.0)
    const mockVideo1 = createTestVideoWithController(config, actionHandler, { playbackRate: 2.0 });
    actionHandler.runAction('reset', 1.0); // Pass the value as keyboard handler would
    expect(mockVideo1.playbackRate).toBe(1.0);

    // Test with custom reset speed
    config.setKeyBinding('reset', 1.5);
    const mockVideo2 = createTestVideoWithController(config, actionHandler, { playbackRate: 2.5 });
    actionHandler.rememberTarget(mockVideo2);
    actionHandler.runAction('reset', 1.5); // Pass the custom value
    expect(mockVideo2.playbackRate).toBe(1.5);

    // Test reset memory toggle functionality with custom reset speed
    const mockVideo3 = createTestVideoWithController(config, actionHandler, { playbackRate: 1.5 });

    // First reset should remember current speed and go to reset speed
    mockVideo3.playbackRate = 2.2;
    actionHandler.rememberTarget(mockVideo3);
    actionHandler.runAction('reset', 1.5); // Pass custom value
    expect(mockVideo3.playbackRate).toBe(1.5); // Should reset to configured value
    expect(mockVideo3.vsc.speedBeforeReset).toBe(2.2); // Should remember previous speed

    // Second reset should restore remembered speed
    actionHandler.runAction('reset', 1.5); // Pass custom value
    expect(mockVideo3.playbackRate).toBe(2.2); // Should restore remembered speed
    expect(mockVideo3.vsc.speedBeforeReset).toBe(null); // Should clear memory
  });

  // --- Cross-toggle tests (reset ↔ preferred speed) ---

  it('reset at target with no memory should cross-toggle to preferred speed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });
    video.vsc.speedBeforeReset = null;

    // Reset at 1.0x with no memory → should cross-toggle to preferred speed (1.8)
    actionHandler.resetSpeed(video, 1.0, 1.8);
    expect(video.playbackRate).toBe(1.8);
    expect(video.vsc.speedBeforeReset).toBe(1.0);
  });

  it('preferred at target with no memory should cross-toggle to reset speed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.8 });
    video.vsc.speedBeforeReset = null;

    // Preferred at 1.8x with no memory → should cross-toggle to reset speed (1.0)
    actionHandler.resetSpeed(video, 1.8, 1.0);
    expect(video.playbackRate).toBe(1.0);
    expect(video.vsc.speedBeforeReset).toBe(1.8);
  });

  it('cross-toggle should not fire when crossTarget equals target', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });
    video.vsc.speedBeforeReset = null;

    // If both reset and preferred are configured to 1.0, cross-toggle should be a no-op
    actionHandler.resetSpeed(video, 1.0, 1.0);
    expect(video.playbackRate).toBe(1.0);
    expect(video.vsc.speedBeforeReset).toBe(null);
  });

  it('cross-toggle should not fire when memory exists', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });
    video.vsc.speedBeforeReset = 2.5;

    // At target with memory → should restore, not cross-toggle
    actionHandler.resetSpeed(video, 1.0, 1.8);
    expect(video.playbackRate).toBe(2.5);
    expect(video.vsc.speedBeforeReset).toBe(null);
  });

  it('reset key should toggle between 1.0 and preferred speed repeatedly', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });
    video.vsc.speedBeforeReset = null;

    // Press 1: at 1.0 with no memory → cross-toggle to 1.8
    actionHandler.resetSpeed(video, 1.0, 1.8);
    expect(video.playbackRate).toBe(1.8);

    // Press 2: at 1.8, not at target (1.0) → remember 1.8, go to 1.0
    actionHandler.resetSpeed(video, 1.0, 1.8);
    expect(video.playbackRate).toBe(1.0);

    // Press 3: at 1.0 with memory (1.8) → restore to 1.8
    actionHandler.resetSpeed(video, 1.0, 1.8);
    expect(video.playbackRate).toBe(1.8);

    // Press 4: at 1.8, not at target (1.0) → remember 1.8, go to 1.0
    actionHandler.resetSpeed(video, 1.0, 1.8);
    expect(video.playbackRate).toBe(1.0);
  });

  it('cross-toggle works end-to-end via runAction with default bindings', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    // Ensure default bindings are in effect
    config.setKeyBinding('reset', 1.0);
    config.setKeyBinding('fast', 1.8);

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });
    video.vsc.speedBeforeReset = null;

    // runAction('reset', 1.0) should cross-toggle to preferred (1.8) via config lookup
    actionHandler.runAction('reset', 1.0);
    expect(video.playbackRate).toBe(1.8);

    // Reset back
    actionHandler.runAction('reset', 1.0);
    expect(video.playbackRate).toBe(1.0);
  });

  it('cross-toggle works end-to-end via runAction for fast action', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    // Ensure default bindings are in effect
    config.setKeyBinding('reset', 1.0);
    config.setKeyBinding('fast', 1.8);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.8 });
    video.vsc.speedBeforeReset = null;

    // runAction('fast', 1.8) should cross-toggle to reset (1.0)
    actionHandler.runAction('fast', 1.8);
    expect(video.playbackRate).toBe(1.0);

    // Fast back
    actionHandler.runAction('fast', 1.8);
    expect(video.playbackRate).toBe(1.8);
  });

  it('cross-toggle with custom reset and preferred speeds', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    // Set custom speeds
    config.setKeyBinding('reset', 1.5);
    config.setKeyBinding('fast', 2.0);

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.5 });
    video.vsc.speedBeforeReset = null;

    // Reset at custom 1.5 with no memory → cross-toggle to custom preferred 2.0
    actionHandler.runAction('reset', 1.5);
    expect(video.playbackRate).toBe(2.0);

    // Toggle back
    actionHandler.runAction('reset', 1.5);
    expect(video.playbackRate).toBe(1.5);
  });

  it('resetSpeed at its target still starts a fresh authority epoch', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.lastSpeed = 2.0;

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);
    const video = createTestVideoWithController(config, actionHandler, { playbackRate: 1.0 });
    video.vsc.speedBeforeReset = null;

    // Called without crossTarget (e.g. popup reset) still expresses a user
    // choice, even though the register already contains 1.0x.
    actionHandler.resetSpeed(video, 1.0);

    expect(video.playbackRate).toBe(1.0);
    expect(video.vsc.speedBeforeReset).toBe(null);
    expect(video.vsc.arbitration.stateFor(video).state.desired).toBe(1.0);
    expect(eventManager.arbitration.authorityFor(video).epoch).toBe(1);
  });

  it('local authority should update during session even when rememberSpeed is false', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();
    config.settings.rememberSpeed = false; // Disable cross-session persistence
    config.settings.lastSpeed = 1.0; // Start with default speed

    const eventManager = new window.VSC.EventManager(config, null);
    const actionHandler = new window.VSC.ActionHandler(config, eventManager);

    // Track storage saves
    const savedCalls = [];
    const originalSave = config.save;
    config.save = function (data) {
      savedCalls.push({ ...data });
      return originalSave.call(config, data);
    };

    const video = createTestVideoWithController(config, actionHandler, {
      currentSrc: 'https://example.com/video.mp4',
    });

    // Change speed to 1.4
    await actionHandler.adjustSpeed(video, 1.4);

    // lastSpeed should be updated in memory for session persistence
    expect(video.vsc.arbitration.stateFor(video).state.desired).toBe(1.4);

    // No storage saves should occur
    expect(savedCalls.length).toBe(0);

    // Simulate play event (which asks the arbiter for the lifecycle target)
    const targetSpeed = video.vsc.arbitration.lifecycleTarget(video);
    expect(targetSpeed).toBe(1.4);

    // Restore original save method
    config.save = originalSave;
  });

  it('default A/D/S keys decrease, increase and reset to the configured speed', async () => {
    const config = window.VSC.videoSpeedConfig;
    await config.load();

    const actionHandler = new window.VSC.ActionHandler(config, null);
    const eventManager = new window.VSC.EventManager(config, actionHandler);
    actionHandler.eventManager = eventManager;

    // Test with custom reset speed via keyboard simulation
    config.setKeyBinding('reset', 1.5);
    const mockVideo = createTestVideoWithController(config, actionHandler, { playbackRate: 2.0 });

    const press = (code, key, keyCode) =>
      eventManager.handleKeydown({
        code,
        key,
        keyCode,
        target: document.body,
        ctrlKey: false,
        altKey: false,
        shiftKey: false,
        metaKey: false,
        isComposing: false,
        timeStamp: 3000,
        preventDefault: () => {},
        stopPropagation: () => {},
      });

    press('KeyA', 'a', 65);
    expect(mockVideo.playbackRate).toBe(1.9);
    press('KeyD', 'd', 68);
    expect(mockVideo.playbackRate).toBe(2.0);
    press('KeyS', 's', 83);
    expect(mockVideo.playbackRate).toBe(1.5); // Should use configured reset speed
  });
});
