import { vi } from 'vitest';
import { getMockStorage } from './chrome-mock.js';

export async function privateWorld({ siteSpeed = null, storedSpeed = 3, remember = true } = {}) {
  Object.assign(getMockStorage(), {
    lastSpeed: storedSpeed,
    rememberSpeed: remember,
    audioBoolean: true,
  });
  const config = new window.VSC.VideoSpeedConfig();
  await config.load();
  config.settings.siteDefaultSpeed = siteSpeed;
  const events = new window.VSC.EventManager(config, null);
  const actions = new window.VSC.ActionHandler(config, events);
  events.actionHandler = actions;
  const media = [];
  function add(tag = 'video', rate = 1, readyState = 4) {
    const wrapper = document.createElement('section');
    const el = document.createElement(tag);
    el.playbackRate = rate;
    Object.defineProperty(el, 'readyState', { value: readyState, configurable: true });
    wrapper.append(el);
    document.body.append(wrapper);
    const controller = new window.VSC.VideoController(el, wrapper, config, actions);
    media.push(el);
    return { el, controller, wrapper };
  }
  return {
    config,
    events,
    actions,
    add,
    media,
    native(el, rate, verdict = 'AUTONOMOUS') {
      el.playbackRate = rate;
      events.arbitration.onExternalRate(
        el,
        { timeStamp: performance.now(), stopImmediatePropagation() {} },
        verdict
      );
    },
    cleanup() {
      for (const el of media) {
        el.vsc?.remove();
        el.parentElement?.remove();
      }
      events.cleanup();
      vi.restoreAllMocks();
    },
  };
}
