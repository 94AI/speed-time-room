export { default } from './private-isolation.e2e.js';
