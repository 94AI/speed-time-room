/** Offline Chrome extension tests using real HTMLMediaElements and two tabs. */
import puppeteer from 'puppeteer';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

export default async function runPrivateIsolationTests() {
  const root = process.cwd();
  const html =
    '<!doctype html><title>倍速時光屋 isolation</title><style>body{font:16px sans-serif;background:#f3f5fa;padding:25px}section{position:relative;background:white;border-radius:12px;padding:15px;margin:15px}video,audio{width:480px;height:80px}input{margin:12px}</style><h1>倍速時光屋: independent video / podcast</h1><section><h2>Video A</h2><video id="a" controls muted src="/media.wav"></video></section><section><h2>Podcast B</h2><audio id="b" controls src="/media.wav"></audio></section><input id="typing" placeholder="typing must not change speed">';
  const server = http.createServer(async (req, res) => {
    try {
      if (new URL(req.url, 'http://localhost').pathname === '/media.wav') {
        res.setHeader('Content-Type', 'audio/wav');
        res.end(await fs.readFile(path.join(root, 'tests/e2e/fixtures/test.wav')));
      } else {
        res.setHeader('Content-Type', 'text/html');
        res.end(html);
      }
    } catch {
      res.statusCode = 500;
      res.end();
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${server.address().port}/`;
  let browser,
    passed = 0,
    failed = 0;
  const test = async (name, fn) => {
    try {
      await fn();
      passed++;
      console.log(`PASS ${name}`);
    } catch (error) {
      failed++;
      console.error(`FAIL ${name}: ${error.stack}`);
    }
  };
  try {
    browser = await puppeteer.launch({
      headless: true,
      pipe: true,
      enableExtensions: [path.join(root, 'dist')],
      executablePath: process.env.CHROME_PATH || undefined,
      args: ['--enable-unsafe-extension-debugging', '--autoplay-policy=no-user-gesture-required'],
    });
    console.log(`Browser: ${await browser.version()}`);
    const worker = await browser.waitForTarget((t) => t.type() === 'service_worker');
    const extensionId = new URL(worker.url()).host;
    const options = await browser.newPage();
    await options.goto(`chrome-extension://${extensionId}/ui/options/options.html`);
    await options.evaluate(async () => {
      await chrome.storage.sync.set({
        enabled: true,
        audioBoolean: true,
        rememberSpeed: true,
        lastSpeed: 3,
        siteRules: [],
        logLevel: 0,
      });
    });
    const page = await browser.newPage();
    const open = async (p) => {
      await p.goto(url);
      await p.waitForFunction(() =>
        ['a', 'b'].every((id) => {
          const el = document.getElementById(id);
          return el.readyState >= 2 && el.vsc;
        })
      );
    };
    const rates = () =>
      page.evaluate(() => ['a', 'b'].map((id) => document.getElementById(id).playbackRate));
    const set = async (a, b) => {
      await page.evaluate(
        ([x, y]) => {
          const action = window.VSC_controller.actionHandler;
          action.adjustSpeed(document.getElementById('a'), x);
          action.adjustSpeed(document.getElementById('b'), y);
        },
        [a, b]
      );
      await new Promise((r) => setTimeout(r, 30));
    };
    await open(page);
    await test('manifest loads with both video and audio controllers; legacy 3x ignored', async () =>
      assert.deepEqual(await rates(), [1, 1]));
    await test('per-player speed survives real seeks and playback', async () => {
      await set(1.35, 2.4);
      await page.evaluate(async () => {
        for (const id of ['a', 'b']) {
          const el = document.getElementById(id);
          el.currentTime = 0.2;
          await el.play();
          el.pause();
        }
      });
      assert.deepEqual(await rates(), [1.35, 2.4]);
    });
    await test('hover + D/A affects one owner', async () => {
      await page.hover('#a');
      await page.keyboard.press('d');
      assert.deepEqual(await rates(), [1.45, 2.4]);
      await page.keyboard.press('a');
      assert.deepEqual(await rates(), [1.35, 2.4]);
    });
    await test('S and G keep per-player toggle memories', async () => {
      await page.hover('#a');
      await page.keyboard.press('s');
      assert.deepEqual(await rates(), [1, 2.4]);
      await page.keyboard.press('s');
      assert.deepEqual(await rates(), [1.35, 2.4]);
      await page.hover('#b');
      await page.keyboard.press('g');
      assert.deepEqual(await rates(), [1.35, 1.8]);
      await page.keyboard.press('g');
      assert.deepEqual(await rates(), [1.35, 2.4]);
    });
    await test('Z/X seek the selected audio only', async () => {
      await page.hover('#b');
      const aTime = await page.$eval('#a', (el) => el.currentTime);
      await page.keyboard.press('x');
      await page.keyboard.press('z');
      assert.equal(await page.$eval('#a', (el) => el.currentTime), aTime);
      assert.deepEqual(await rates(), [1.35, 2.4]);
    });
    await test('typing keeps both playback rates', async () => {
      await page.click('#typing');
      await page.keyboard.type('adsgzx');
      assert.deepEqual(await rates(), [1.35, 2.4]);
      await page.$eval('#typing', (el) => el.blur());
    });
    await test('controller buttons retain appearance and target owner', async () => {
      await page.evaluate(() => {
        const b = document.getElementById('b');
        b.vsc.div.shadowRoot.querySelector('[data-action="faster"]').click();
      });
      assert.deepEqual(await rates(), [1.35, 2.5]);
      assert.equal(await page.$eval('#b', (el) => el.vsc.speedIndicator.textContent), '2.50');
    });
    await test('source replacement retains same-element authority', async () => {
      await page.$eval('#b', (el) => {
        el.src = '/media.wav?replacement';
        el.load();
      });
      await page.waitForFunction(() => document.getElementById('b').readyState >= 2);
      await page.$eval('#b', (el) => el.dispatchEvent(new Event('play')));
      assert.deepEqual(await rates(), [1.35, 2.5]);
    });
    await test('newly inserted audio ignores another player speed and stored lastSpeed', async () => {
      await page.evaluate(() => {
        const box = document.createElement('section');
        box.innerHTML = '<audio id="c" controls src="/media.wav"></audio>';
        document.body.append(box);
      });
      await page.waitForFunction(() => document.getElementById('c')?.vsc);
      assert.equal(await page.$eval('#c', (el) => el.playbackRate), 1);
      await page.$eval('#c', (el) => el.parentElement.remove());
    });
    const second = await browser.newPage();
    await open(second);
    await test('separate tabs and storage changes cannot replace existing targets', async () => {
      await second.evaluate(() =>
        window.VSC_controller.actionHandler.adjustSpeed(document.getElementById('a'), 1.9)
      );
      await options.evaluate(async () => chrome.storage.sync.set({ lastSpeed: 4 }));
      await new Promise((r) => setTimeout(r, 100));
      await page.evaluate(() => {
        for (const el of document.querySelectorAll('video,audio')) {
          el.dispatchEvent(new Event('play'));
          el.dispatchEvent(new Event('seeked'));
        }
      });
      assert.deepEqual(await rates(), [1.35, 2.5]);
      assert.equal(await second.$eval('#a', (el) => el.playbackRate), 1.9);
    });
    await test('popup bridge targets only selected player', async () => {
      await page.bringToFront();
      await page.click('#a');
      await page.$eval('#a', (el) => el.pause());
      await options.evaluate(async () => {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(
          tab.id,
          { type: 'VSC_SET_SPEED', payload: { speed: 1.6 } },
          { frameId: 0 }
        );
      });
      assert.deepEqual(await rates(), [1.6, 2.5]);
    });
    await test('settings and custom shortcut remain usable', async () => {
      await options.waitForSelector('#rememberSpeed');
      assert.equal(await options.$eval('#rememberSpeed', (el) => el.disabled), true);
      const bindings = await page.evaluate(() => window.VSC_controller.config.settings.keyBindings);
      await options.evaluate(async (keyBindings) => {
        await chrome.storage.sync.set({
          keyBindings: keyBindings.map((b) =>
            b.action === 'faster' ? { ...b, code: 'KeyQ', key: 81, keyCode: 81 } : b
          ),
        });
      }, bindings);
      await page.reload();
      await page.waitForFunction(() => document.getElementById('a')?.vsc);
      await page.hover('#a');
      await page.keyboard.press('q');
      assert.deepEqual(await rates(), [1.1, 1]);
    });
    if (process.env.PRIVATE_SCREENSHOT) {
      await page.screenshot({ path: process.env.PRIVATE_SCREENSHOT, fullPage: true });
    }
  } finally {
    await browser?.close();
    await new Promise((resolve) => server.close(resolve));
  }
  console.log(`Private browser tests: ${passed} passed, ${failed} failed`);
  return { passed, failed };
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const result = await runPrivateIsolationTests();
  process.exitCode = result.failed ? 1 : 0;
}
