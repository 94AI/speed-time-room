/**
 * Speed arbitration adapter — maps DOM observations onto per-media conflict
 * states with independent desired speeds for every media element.
 *
 * Desired speed and authority generation live in a media-keyed WeakMap.
 * lastSpeed is never a playback source. A choice on A cannot invalidate B's
 * conflict budget, write echoes, hold, timer, or lifecycle restore target.
 */

window.VSC = window.VSC || {};

class SpeedArbitration {
  /**
   * @param {Object} config
   * @param {Object|null} eventManager
   */
  constructor(config, eventManager) {
    this.config = config;
    this.eventManager = eventManager;
    this.classifier = new window.VSC.IntentClassifier({
      // Site handlers declare evidence-rule activations (getClassifierRules);
      // the classifier owns what each flag means. Late-bound through the
      // namespace like resolveGestureMedia: handler detection is lazy and
      // static (matches() on location.hostname), so construction order is
      // irrelevant and non-handler contexts fall back to generic rules.
      rules: Object.freeze({
        ...window.VSC.IntentClassifier.TARGET_RULES,
        ...(window.VSC.siteHandlerManager?.getClassifierRules?.() || {}),
      }),
      minRate: window.VSC.Constants.SPEED_LIMITS.MIN,
    });

    // Retain identity across controller removal/re-attachment of the same
    // element, without retaining detached DOM nodes. New elements start fresh.
    this.authorities = new WeakMap();
    this.conflicts = new WeakMap();
    this.timedConflicts = new Set();

    // Native write echoes are media-local: a token for A must never absorb
    // B's ratechange. One short transaction follows an ordinary echo through
    // its target listeners and, only when they rewrite A, to the resulting
    // counter-event. The enumerable Map is bounded by controlled media and is
    // cleared on authority change, resource change, release, and cleanup.
    this.pendingWrites = new WeakMap();
    this.echoTransactions = new Map();

    // A document-capture terminal event runs before some player handlers.
    // Keep a short, cancellable fallback only for a player that never emits
    // its expected normal release ratechange; ordinary releases clear it.
    this.temporaryReleaseTimers = new WeakMap();
    this.pendingTemporaryReleaseTimers = new Set();
  }

  /**
   * Record an extension-issued register write for the media-local echo filter.
   * A causally proven feedback-loop retry may hide its echo from page listeners;
   * ordinary writes remain observable.
   * @param {HTMLMediaElement} video
   * @param {number} rate
   * @param {{suppressPropagation?: boolean}} [options]
   */
  noteWrite(video, rate, { suppressPropagation = false } = {}) {
    let queue = this.pendingWrites.get(video);
    if (!queue) {
      queue = [];
      this.pendingWrites.set(video, queue);
    }
    queue.push({
      rate,
      at: performance.now(),
      epoch: this.authorityFor(video).epoch,
      suppressPropagation,
    });
    if (queue.length > SpeedArbitration.ECHO_MAX_PENDING) {
      queue.shift();
    }
  }

  /**
   * Consume a matching extension write token.
   * @param {HTMLMediaElement} video
   * @param {number} rate
   * @returns {{rate: number, at: number, epoch: number, suppressPropagation: boolean}|false}
   */
  consumeEcho(video, rate) {
    let queue = this.pendingWrites.get(video);
    if (!queue || queue.length === 0) {
      return false;
    }
    const now = performance.now();
    // A fresh user/native choice starts a new authority epoch. An echo from
    // an older epoch must not mask a real site reset that happens to reuse
    // the old rate, even during the short token TTL.
    queue = queue.filter(
      (write) =>
        write.epoch === this.authorityFor(video).epoch &&
        now - write.at <= SpeedArbitration.ECHO_TTL_MS
    );
    if (queue.length === 0) {
      this.pendingWrites.delete(video);
      return false;
    }
    this.pendingWrites.set(video, queue);
    const idx = queue.findIndex(
      (write) => Math.abs(write.rate - rate) <= SpeedArbitration.ECHO_TOLERANCE
    );
    if (idx === -1) {
      // A hidden echo must never linger and suppress a later genuine event if
      // an earlier page-capture listener rewrote the register before VSC saw it.
      const visibleWrites = queue.filter((write) => !write.suppressPropagation);
      if (visibleWrites.length === 0) {
        this.pendingWrites.delete(video);
      } else {
        this.pendingWrites.set(video, visibleWrites);
      }
      return false;
    }
    const echo = queue[idx];
    queue.splice(0, idx + 1);
    return echo;
  }

  /**
   * Follow an ordinary VSC echo to the media target, after page listeners that
   * were registered before this dispatch. If they rewrite the register, retain
   * one transaction until the browser delivers that setter's counter-event.
   * @param {HTMLMediaElement} video
   * @param {Event} event
   * @param {{rate: number, epoch: number}} echo
   */
  observePropagatedEcho(video, event, echo) {
    this.clearEchoTransaction(video);
    const transaction = {
      epoch: echo.epoch,
      expectedRate: echo.rate,
      sourceEvent: event,
      observedRate: null,
      listener: null,
    };
    transaction.listener = (targetEvent) => {
      if (
        targetEvent !== transaction.sourceEvent ||
        this.echoTransactions.get(video) !== transaction
      ) {
        return;
      }

      video.removeEventListener('ratechange', transaction.listener);
      transaction.listener = null;
      if (transaction.epoch !== this.authorityFor(video).epoch) {
        this.clearEchoTransaction(video);
        return;
      }

      const observedRate = video.playbackRate;
      if (Math.abs(observedRate - transaction.expectedRate) <= SpeedArbitration.ECHO_TOLERANCE) {
        this.clearEchoTransaction(video);
        return;
      }

      transaction.sourceEvent = null;
      transaction.observedRate = observedRate;
    };
    this.echoTransactions.set(video, transaction);
    video.addEventListener('ratechange', transaction.listener);
  }

  /**
   * @param {HTMLMediaElement} video
   */
  clearEchoTransaction(video) {
    const transaction = this.echoTransactions.get(video);
    if (!transaction) {
      return;
    }
    if (transaction.listener) {
      video.removeEventListener('ratechange', transaction.listener);
    }
    this.echoTransactions.delete(video);
  }

  clearAllEchoTransactions() {
    for (const video of [...this.echoTransactions.keys()]) {
      this.clearEchoTransaction(video);
    }
  }

  /**
   * Resolve causal evidence before generic classification. A nested synthetic
   * event is deferred until the outer echo reaches its target tail; a completed
   * transaction consumes exactly the next same-media external event.
   * @param {HTMLMediaElement} video
   * @param {Event} event
   * @returns {boolean|null} true for a rewrite, null to defer a nested event
   */
  consumeEchoReaction(video, event) {
    const transaction = this.echoTransactions.get(video);
    if (!transaction) {
      return false;
    }

    if (transaction.epoch !== this.authorityFor(video).epoch) {
      this.clearEchoTransaction(video);
      return false;
    }

    if (transaction.observedRate === null) {
      const sourceEventActive =
        transaction.sourceEvent !== event &&
        Number.isFinite(transaction.sourceEvent?.eventPhase) &&
        transaction.sourceEvent.eventPhase !== Event.NONE;
      if (sourceEventActive) {
        return null;
      }
      this.clearEchoTransaction(video);
      return false;
    }

    const rewriteMatches =
      Math.abs(transaction.observedRate - video.playbackRate) <= SpeedArbitration.ECHO_TOLERANCE;
    this.clearEchoTransaction(video);
    return rewriteMatches;
  }

  /**
   * Materialize the pure state from this element's authority and conflict record.
   * @param {HTMLMediaElement} video
   * @returns {{state: Object, conflict: Object|null}}
   * @private
   */
  stateFor(video) {
    const authority = this.authorityFor(video);
    const conflict = this.conflictFor(video);
    return {
      conflict,
      state: {
        mode: conflict.mode,
        desired: authority.desired,
        fightCount: conflict.fightCount,
        warQuiet: conflict.warQuiet,
        rearmBudget: conflict.rearmBudget,
        temporaryOverride: conflict.temporaryOverride,
      },
    };
  }

  authorityFor(video) {
    let authority = this.authorities.get(video);
    if (!authority) {
      // Only an explicit site rule may seed multiple new players. Neither
      // persisted lastSpeed nor another player's latest choice is consulted.
      const seed = this.config.settings.siteDefaultSpeed;
      authority = {
        desired: Number.isFinite(seed) && seed > 0 ? seed : null,
        epoch: 0,
      };
      this.authorities.set(video, authority);
    }
    return authority;
  }

  /**
   * Get the conflict record for this element's current authority generation.
   * @param {HTMLMediaElement} video
   * @returns {Object}
   * @private
   */
  conflictFor(video) {
    const authority = this.authorityFor(video);
    let conflict = this.conflicts.get(video);
    if (!conflict || conflict.epoch !== authority.epoch) {
      if (conflict) {
        this.clearFightTimer(conflict);
      }
      conflict = {
        epoch: this.authorityFor(video).epoch,
        mode:
          authority.desired === null
            ? window.VSC.SpeedArbiter.MODES.NO_OPINION
            : window.VSC.SpeedArbiter.MODES.HOLDING,
        fightCount: 0,
        warQuiet: true,
        rearmBudget: window.VSC.SpeedArbiter.DEFAULT_REARM_BUDGET,
        temporaryOverride: false,
        fightTimer: null,
      };
      this.conflicts.set(video, conflict);
    }
    return conflict;
  }

  /**
   * @param {Object|null} conflict
   * @param {Object} state
   * @private
   */
  applyState(conflict, state) {
    if (!conflict) {
      return;
    }
    conflict.mode = state.mode;
    conflict.fightCount = state.fightCount;
    conflict.warQuiet = state.warQuiet;
    conflict.rearmBudget = state.rearmBudget;
    conflict.temporaryOverride = state.temporaryOverride;
  }

  /** Claim authority for this element only, even for a same-value choice. */
  claimAuthority(video, speed) {
    const authority = this.authorityFor(video);
    authority.desired = speed;
    authority.epoch += 1;
    const conflict = this.conflicts.get(video);
    this.clearFightTimer(conflict);
    this.clearEchoTransaction(video);
    this.clearTemporaryReleaseTimer(video);
    this.pendingWrites.delete(video);
  }

  /** USER_SET from shortcuts, controller, wheel, drag, or popup. */
  noteUserSet(video, speed) {
    const A = window.VSC.SpeedArbiter;
    this.claimAuthority(video, speed);
    const { state } = this.stateFor(video);
    const result = A.step(state, { type: A.EVENTS.USER_SET, speed });
    this.applyState(this.conflictFor(video), result.state);
  }

  /**
   * Schedule a fallback for a physical terminal event. The usual YouTube
   * release emits a normal ratechange first; the fallback only prevents an
   * abandoned hold from suppressing lifecycle healing forever.
   * @param {HTMLMediaElement} video
   */
  noteTemporaryOverrideEnd(video) {
    const conflict = this.conflicts.get(video);
    if (!conflict?.temporaryOverride || this.temporaryReleaseTimers.get(video)) {
      return;
    }

    const entry = { video, timer: null };
    entry.timer = setTimeout(() => {
      this.pendingTemporaryReleaseTimers.delete(entry);
      if (this.temporaryReleaseTimers.get(video) !== entry) {
        return;
      }
      this.temporaryReleaseTimers.delete(video);
      if (this.stateFor(video).state.temporaryOverride) {
        window.VSC.logger.info(
          'Restoring player speed after native hold release without ratechange'
        );
        this.completeTemporaryOverride(video, video.playbackRate);
      }
    }, SpeedArbitration.TEMPORARY_RELEASE_FALLBACK_MS);
    this.temporaryReleaseTimers.set(video, entry);
    this.pendingTemporaryReleaseTimers.add(entry);
  }

  /**
   * Complete a local temporary override from its normal external release or
   * the guarded terminal fallback. This never claims player authority.
   * @param {HTMLMediaElement} video
   * @param {number} observedRate
   * @param {Event|null} [event]
   * @returns {boolean} whether a temporary override was completed
   * @private
   */
  completeTemporaryOverride(video, observedRate, event = null) {
    const A = window.VSC.SpeedArbiter;
    this.clearTemporaryReleaseTimer(video);
    const { state, conflict } = this.stateFor(video);
    if (!state.temporaryOverride) {
      return false;
    }
    const { state: next, effects } = A.step(state, {
      type: A.EVENTS.TEMPORARY_OVERRIDE_END,
      speed: observedRate,
    });
    this.applyState(conflict, next);
    const write = effects.find((entry) => entry.type === A.EFFECTS.WRITE);
    const sync = effects.find((entry) => entry.type === A.EFFECTS.SYNC_UI);
    if (write) {
      window.VSC.logger.info(
        `Restoring player speed ${write.speed} after temporary native override`
      );
      this.eventManager?.actionHandler?.writeRate(video, write.speed);
      event?.stopImmediatePropagation();
    }
    if (sync) {
      this.eventManager?.actionHandler?.syncIndicator(video, sync.speed);
    }
    return true;
  }

  /**
   * @param {HTMLMediaElement} video
   * @private
   */
  clearTemporaryReleaseTimer(video) {
    const entry = this.temporaryReleaseTimers.get(video);
    if (!entry) {
      return;
    }
    clearTimeout(entry.timer);
    this.temporaryReleaseTimers.delete(video);
    this.pendingTemporaryReleaseTimers.delete(entry);
  }

  /**
   * Decide and execute for a genuine external ratechange.
   * @param {HTMLMediaElement} video
   * @param {Event} event
   * @param {string} verdict
   * @param {{suppressRetryEcho?: boolean}} [options]
   */
  onExternalRate(video, event, verdict, { suppressRetryEcho = false } = {}) {
    const A = window.VSC.SpeedArbiter;
    const IC = window.VSC.IntentClassifier;
    const rawRate = video.playbackRate;
    const { state, conflict } = this.stateFor(video);
    if (suppressRetryEcho) {
      window.VSC.logger.info(
        `Detected page rewrite caused by propagated VSC echo: ${state.desired} -> ${rawRate}`
      );
    }

    // A known temporary hold owns only this media register. Its first normal
    // ratechange is the native release even when weak release click/Space
    // evidence is present. Explicit strong speed-key/menu intent still wins,
    // so a deliberate native choice can supersede the hold.
    const strongUserIntent =
      verdict === IC.VERDICTS.USER_INTENT &&
      this.classifier.hasStrongIntent({ media: video, timeStamp: event.timeStamp });
    // Once a physical terminal event scheduled its fallback, the next normal
    // ratechange belongs to that release—even if its click joins a prior menu
    // click into a strong sequence. Before a terminal, explicit strong speed
    // intent still supersedes the hold.
    const releasePending = !!this.temporaryReleaseTimers.get(video);
    if (
      state.temporaryOverride &&
      verdict !== IC.VERDICTS.TEMPORARY_OVERRIDE &&
      (!strongUserIntent || releasePending)
    ) {
      this.completeTemporaryOverride(video, rawRate, event);
      return;
    }

    if (verdict === IC.VERDICTS.TEMPORARY_OVERRIDE) {
      this.clearTemporaryReleaseTimer(video);
      const { state: next, effects } = A.step(state, {
        type: A.EVENTS.TEMPORARY_OVERRIDE_START,
        speed: rawRate,
      });
      this.applyState(conflict, next);
      const sync = effects.find((entry) => entry.type === A.EFFECTS.SYNC_UI);
      if (sync) {
        window.VSC.logger.info(
          `Allowing temporary native override at ${rawRate} without claiming player authority`
        );
        this.eventManager?.actionHandler?.syncIndicator(video, sync.speed);
      }
      return;
    }

    let rateClass = verdict;
    let speedForDecision = rawRate;
    if (state.mode === A.MODES.HOLDING && Math.abs(rawRate - state.desired) <= 0.01) {
      speedForDecision = state.desired;
      if (rateClass === IC.VERDICTS.USER_INTENT) {
        rateClass = IC.VERDICTS.AUTONOMOUS;
      }
    }

    const previousFightCount = state.fightCount;
    const { state: next, effects } = A.step(state, {
      type: A.EVENTS.EXT_RATE,
      speed: speedForDecision,
      rateClass,
      quiet: this.classifier.isQuietContext(event.timeStamp),
    });

    const inputAge =
      this.classifier.lastInputAt > 0
        ? Math.round(event.timeStamp - this.classifier.lastInputAt)
        : -1;

    if (effects.some((entry) => entry.type === A.EFFECTS.PERSIST)) {
      const adopted = Number(rawRate.toFixed(2));
      window.VSC.logger.info(
        `Accepting site speed change as user-intentional: ${rawRate} (input ${inputAge}ms ago)`
      );
      if (conflict) {
        this.clearFightTimer(conflict);
      }
      this.clearTemporaryReleaseTimer(video);
      this.classifier.consumeGesture(video);
      this.claimAuthority(video, adopted);
      this.applyState(this.conflictFor(video), next);
      this.eventManager?.actionHandler?.syncIndicator(video, adopted);
      return;
    }

    this.applyState(conflict, next);

    if (next.fightCount > previousFightCount) {
      this.armFightTimer(video, conflict);
      window.VSC.logger.info(
        `Fight detection: attempt ${next.fightCount}, site rate ${rawRate} -> re-applying ${state.desired} (input ${inputAge}ms ago)`
      );
      this.eventManager?.actionHandler?.writeRate(video, state.desired, {
        suppressEchoPropagation: suppressRetryEcho,
      });
      event.stopImmediatePropagation();
      return;
    }

    if (
      (next.mode === A.MODES.SUPPRESSED || next.mode === A.MODES.REARMABLE) &&
      next.mode !== state.mode
    ) {
      // The prior fight timer belongs to the completed exchange. Leaving it
      // alive would retain this media record until expiry and could mutate its
      // count after a local stand-down/re-arm decision.
      this.clearFightTimer(conflict);
      window.VSC.logger.info(
        `Fight detection: ${next.mode.toLowerCase()} locally at site speed ${rawRate}`
      );
    }
    this.eventManager?.actionHandler?.syncIndicator(video, rawRate);
  }

  /**
   * Return the lifecycle write target for one media element, if it remains
   * locally enforcing player authority.
   * @param {HTMLMediaElement} video
   * @returns {number|null}
   */
  lifecycleTarget(video) {
    const A = window.VSC.SpeedArbiter;
    const { state, conflict } = this.stateFor(video);
    const { state: next, effects } = A.step(state, { type: A.EVENTS.LIFECYCLE });
    this.applyState(conflict, next);
    const write = effects.find((entry) => entry.type === A.EFFECTS.WRITE);
    return write ? write.speed : null;
  }

  /**
   * Release state associated with a removed controller.
   * @param {HTMLMediaElement} video
   */
  release(video) {
    const conflict = this.conflicts.get(video);
    if (conflict) {
      this.clearFightTimer(conflict);
      this.conflicts.delete(video);
    }
    this.pendingWrites.delete(video);
    this.clearEchoTransaction(video);
    this.clearTemporaryReleaseTimer(video);
    this.classifier.releaseMedia(video);
  }

  /**
   * @param {Object|null} conflict
   * @private
   */
  armFightTimer(video, conflict) {
    if (!conflict) {
      return;
    }
    this.clearFightTimer(conflict);
    const epoch = conflict.epoch;
    conflict.fightTimer = setTimeout(() => {
      this.timedConflicts.delete(conflict);
      conflict.fightTimer = null;
      if (conflict.epoch === epoch && epoch === this.authorityFor(video).epoch) {
        const A = window.VSC.SpeedArbiter;
        const { state } = A.step(
          {
            mode: conflict.mode,
            desired: this.authorityFor(video).desired,
            fightCount: conflict.fightCount,
            warQuiet: conflict.warQuiet,
            rearmBudget: conflict.rearmBudget,
            temporaryOverride: conflict.temporaryOverride,
          },
          { type: A.EVENTS.FIGHT_WINDOW_EXPIRE }
        );
        this.applyState(conflict, state);
      }
    }, SpeedArbitration.FIGHT_WINDOW_MS);
    this.timedConflicts.add(conflict);
  }

  /**
   * @param {Object|null} conflict
   * @private
   */
  clearFightTimer(conflict) {
    if (!conflict || conflict.fightTimer === null) {
      return;
    }
    clearTimeout(conflict.fightTimer);
    conflict.fightTimer = null;
    this.timedConflicts.delete(conflict);
  }

  cleanup() {
    for (const conflict of this.timedConflicts) {
      clearTimeout(conflict.fightTimer);
      conflict.fightTimer = null;
    }
    this.timedConflicts.clear();
    for (const entry of this.pendingTemporaryReleaseTimers) {
      clearTimeout(entry.timer);
    }
    this.pendingTemporaryReleaseTimers.clear();
    this.clearAllEchoTransactions();
    this.temporaryReleaseTimers = new WeakMap();
    this.conflicts = new WeakMap();
    this.pendingWrites = new WeakMap();
    this.authorities = new WeakMap();
    this.classifier.reset();
  }
}

SpeedArbitration.FIGHT_WINDOW_MS = 3000;
SpeedArbitration.ECHO_TOLERANCE = 0.011;
SpeedArbitration.ECHO_TTL_MS = 500;
SpeedArbitration.ECHO_MAX_PENDING = 8;
SpeedArbitration.TEMPORARY_RELEASE_FALLBACK_MS = 250;

window.VSC.SpeedArbitration = SpeedArbitration;
