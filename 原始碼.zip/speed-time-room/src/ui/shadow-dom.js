/**
 * Shadow DOM creation and management
 */

window.VSC = window.VSC || {};

class ShadowDOMManager {
  /**
   * Create shadow DOM for video controller
   * @param {HTMLElement} wrapper - Wrapper element
   * @param {Object} options - Configuration options
   * @returns {ShadowRoot} Created shadow root
   */
  static createShadowDOM(wrapper, options = {}) {
    const { top = '0px', left = '0px', speed = '1.00', opacity = 0.3, buttonSize = 14 } = options;

    const numericOpacity = Number(opacity);
    const glassOpacity = Number.isFinite(numericOpacity)
      ? Math.min(1, Math.max(0, numericOpacity))
      : 0.3;
    const shadow = wrapper.attachShadow({ mode: 'open' });

    // Create style element with embedded CSS for immediate styling
    const style = document.createElement('style');
    style.textContent = `
      * {
        box-sizing: border-box;
        line-height: 1.8em;
        font-family: -apple-system, BlinkMacSystemFont, "PingFang TC", "Segoe UI", sans-serif;
        font-size: 13px;
      }
      :host(:hover) #controls, #controller.preview-expanded #controls {
        display: inline-block;
      }
      /* Keep the existing visibility precedence, independent of glass density. */
      :host(.vsc-hidden) #controller {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
      }
      :host([data-vsc-visibility="show"]) #controller,
      :host(.vsc-show) #controller {
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
      }
      :host([data-vsc-visibility="hide"]) #controller,
      :host(.vsc-nosource) #controller {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
      }
      #controller {
        --vsc-glass-rgb: 248, 250, 255;
        --vsc-glass-ink: #1e293b;
        position: absolute;
        top: 0;
        left: 0;
        background:
          linear-gradient(140deg, rgba(255,255,255,.38), rgba(255,255,255,.06) 52%, rgba(255,255,255,.2)),
          rgba(var(--vsc-glass-rgb), var(--vsc-glass-opacity, .3));
        color: var(--vsc-glass-ink);
        -webkit-backdrop-filter: blur(18px) saturate(180%);
        backdrop-filter: blur(18px) saturate(180%);
        border: 1px solid rgba(255,255,255,.58);
        border-radius: 18px;
        box-shadow:
          0 6px 22px rgba(15,23,42,.18),
          0 1px 3px rgba(15,23,42,.1),
          inset 0 1px 0 rgba(255,255,255,.8),
          inset 0 -1px 0 rgba(255,255,255,.16);
        text-shadow: 0 1px 1px rgba(255,255,255,.55);
        padding: 5px 7px;
        margin: 10px 10px 10px 15px;
        cursor: default;
        z-index: 9999999;
        white-space: nowrap;
        opacity: 1;
        transition: box-shadow .18s ease, border-color .18s ease;
      }
      #controller:hover {
        border-color: rgba(255,255,255,.85);
        box-shadow: 0 8px 28px rgba(15,23,42,.22), inset 0 1px 0 rgba(255,255,255,.9);
      }
      #controller:hover > .draggable,
      #controller.preview-expanded > .draggable {
        margin-right: .55em;
      }
      #controls {
        display: none;
        vertical-align: middle;
      }
      #controller.dragging {
        cursor: grabbing;
      }
      #controller.dragging #controls {
        display: inline-block;
      }
      .draggable {
        cursor: grab;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 2.8em;
        height: 1.55em;
        padding: 0 .2em;
        text-align: center;
        vertical-align: middle;
        touch-action: none;
        font-weight: 750;
        font-variant-numeric: tabular-nums;
        letter-spacing: -.02em;
      }
      .draggable:active { cursor: grabbing; }
      button {
        appearance: none;
        opacity: 1;
        cursor: pointer;
        color: inherit;
        background: rgba(255,255,255,.26);
        font-weight: 500;
        border-radius: 10px;
        padding: 1px 6px 2px;
        min-width: 1.7em;
        font-size: inherit;
        line-height: inherit;
        border: 1px solid rgba(255,255,255,.3);
        box-shadow: inset 0 1px 0 rgba(255,255,255,.4);
        font-family: inherit;
        margin: 0 2px;
        transition: background .15s ease, transform .15s ease;
      }
      button:focus-visible {
        outline: 2px solid #0a84ff;
        outline-offset: 2px;
      }
      button:hover { background: rgba(255,255,255,.5); }
      button:active { background: rgba(255,255,255,.65); transform: translateY(1px); }
      button.rw { opacity: .85; }
      #controller.preview-expanded { position: relative; margin: 0; width: max-content; }
      @media (prefers-color-scheme: dark) {
        #controller {
          --vsc-glass-rgb: 20, 26, 39;
          --vsc-glass-ink: #f8fafc;
          border-color: rgba(255,255,255,.28);
          text-shadow: 0 1px 2px rgba(0,0,0,.5);
          background:
            linear-gradient(140deg, rgba(255,255,255,.17), rgba(255,255,255,.025) 52%, rgba(255,255,255,.07)),
            rgba(var(--vsc-glass-rgb), var(--vsc-glass-opacity, .3));
        }
        button { background: rgba(255,255,255,.1); border-color: rgba(255,255,255,.14); }
        button:hover { background: rgba(255,255,255,.22); }
      }
      @media (prefers-reduced-motion: reduce) {
        #controller, button { transition: none; }
      }
    `;
    shadow.appendChild(style);

    // Create controller div
    const controller = document.createElement('div');
    controller.id = 'controller';
    controller.style.cssText = `top:${top}; left:${left}; --vsc-glass-opacity:${glassOpacity};`;

    // Create draggable speed indicator
    const draggable = document.createElement('span');
    draggable.setAttribute('data-action', 'drag');
    draggable.className = 'draggable';
    draggable.style.cssText = `font-size: ${Math.round(buttonSize * 1.4)}px;`;
    draggable.textContent = speed;
    draggable.title = '目前倍速；拖曳可移動，按兩下可重設';
    draggable.setAttribute('aria-label', '目前倍速');
    controller.appendChild(draggable);

    // Create controls span
    const controls = document.createElement('span');
    controls.id = 'controls';
    controls.style.cssText = `font-size: ${buttonSize}px; line-height: ${buttonSize}px;`;

    // Create buttons
    const buttons = [
      { action: 'rewind', text: '«', class: 'rw', label: '倒退' },
      { action: 'slower', text: '−', class: '', label: '降低倍速' },
      { action: 'faster', text: '+', class: '', label: '提高倍速' },
      { action: 'advance', text: '»', class: 'rw', label: '快進' },
    ];

    buttons.forEach((btnConfig) => {
      const button = document.createElement('button');
      button.setAttribute('data-action', btnConfig.action);
      button.title = btnConfig.label;
      button.setAttribute('aria-label', btnConfig.label);
      if (btnConfig.class) {
        button.className = btnConfig.class;
      }
      button.textContent = btnConfig.text;
      controls.appendChild(button);
    });

    controller.appendChild(controls);
    shadow.appendChild(controller);

    window.VSC.logger.debug('Shadow DOM created for video controller');
    return shadow;
  }

  /**
   * Get controller element from shadow DOM
   * @param {ShadowRoot} shadow - Shadow root
   * @returns {HTMLElement} Controller element
   */
  static getController(shadow) {
    return shadow.querySelector('#controller');
  }

  /**
   * Get controls container from shadow DOM
   * @param {ShadowRoot} shadow - Shadow root
   * @returns {HTMLElement} Controls element
   */
  static getControls(shadow) {
    return shadow.querySelector('#controls');
  }

  /**
   * Get draggable speed indicator from shadow DOM
   * @param {ShadowRoot} shadow - Shadow root
   * @returns {HTMLElement} Speed indicator element
   */
  static getSpeedIndicator(shadow) {
    return shadow.querySelector('.draggable');
  }

  /**
   * Get all buttons from shadow DOM
   * @param {ShadowRoot} shadow - Shadow root
   * @returns {NodeList} Button elements
   */
  static getButtons(shadow) {
    return shadow.querySelectorAll('button');
  }

  /**
   * Update speed display in shadow DOM
   * @param {ShadowRoot} shadow - Shadow root
   * @param {number} speed - New speed value
   */
  static updateSpeedDisplay(shadow, speed) {
    const speedIndicator = this.getSpeedIndicator(shadow);
    if (speedIndicator) {
      speedIndicator.textContent = window.VSC.Constants.formatSpeed(speed);
    }
  }

  /**
   * Calculate position for controller based on video element
   * @param {HTMLVideoElement} video - Video element
   * @returns {Object} Position object with top and left properties
   */
  static calculatePosition(video) {
    const rect = video.getBoundingClientRect();

    // getBoundingClientRect is relative to the viewport; style coordinates
    // are relative to offsetParent, so we adjust for that here. offsetParent
    // can be null if the video has `display: none` or is not yet in the DOM.
    const offsetRect = video.offsetParent?.getBoundingClientRect();
    const top = `${Math.max(rect.top - (offsetRect?.top || 0), 0)}px`;
    const left = `${Math.max(rect.left - (offsetRect?.left || 0), 0)}px`;

    return { top, left };
  }
}

// Create singleton instance
window.VSC.ShadowDOMManager = ShadowDOMManager;
